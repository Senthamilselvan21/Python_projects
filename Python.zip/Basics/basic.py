items=20
price=30.5
name="potato"
print ("Hi ",name," the no.of ",items," items price is ",price)
print ("Hi %s the no of %d items price is %f"%(name,items,price))
