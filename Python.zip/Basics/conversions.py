num=int(input("Enter number:"))
print("octal conversion:0%o"%(num))
print("hexa decimal conversion:0x%x"%(num))
