'''
syntax
for data in range(args):
	statements
'''
for i in range(5):
	print("value is:",i)
print ("********************")
for j in range(1,5):
	print("value is:",j)
print ("*********************")
for k in range(1,10,2):
	print("value is:",k)
