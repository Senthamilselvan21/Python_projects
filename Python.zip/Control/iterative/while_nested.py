x=0
y=0
while x<5:
   y=0
   while y<3:
      print("x is:",x,"y is:",y)
      y=y+1
   x=x+1
