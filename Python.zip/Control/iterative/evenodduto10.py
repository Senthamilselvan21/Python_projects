n=int(input("enter a num to range:"))
for num in range(1,n):
	if num%2==0:
		print ("%d is even"%(num))
	else:
		print ("%d is odd"%(num))
