while True:
	print("Infinite")
