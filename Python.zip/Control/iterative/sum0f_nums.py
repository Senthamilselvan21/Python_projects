sum=0
for i in range(6):
	print("i is:",i)
	sum=sum+i
	print("sum:",sum)
print ("sum is:",sum)	
