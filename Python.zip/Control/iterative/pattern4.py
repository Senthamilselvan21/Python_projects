for i in range(6):
	for j in range(5-i):
		print(j,end=" ")
	print("\n")

