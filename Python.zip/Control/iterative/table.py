for i in range(1,6):
	for j in range(1,11):
		print ("%dx%d=%d"%(i,j,i*j))
	print("*****************")
