for i in range(6):
	for j in range(5-i):
		print(5-i,end=" ")
	print("\n")

