for i in range(1,5):
	for j in range(3):
		print ("i is:",i,"j is:",j)
	print("**************")
