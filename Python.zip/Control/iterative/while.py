'''
initialization
while condition:
	statements
	updation/modification
'''
i =0
while i<10:
	print("i is:",i)
	i=i+1
print("After exit from loop")
