'''
syntax:
if condition:
    statements
else:
	statements
'''

age=int(input("Enter an age:"))
if age>= 18:
    print ("Person eligible for vote")
else:
	print ("Person not eligible for vote")


