num=int(input("enter a number"))
if num%2==0:
	print "EVEN"
else:
	print "ODD"
