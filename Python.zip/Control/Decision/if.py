'''
syntax:
if condition:
	statement
'''
age=int(input("Enter an age:"))
if age>= 18:
    print ("Person eligible for vote")
print ("Person not eligible for vote")
