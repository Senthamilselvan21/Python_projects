from calculator import * 
print ("addition is:",sume(6,3))
print ("substraction is:",subs(6,3))
print ("multiplication is:",mult(6,3))
print ("division is:",divi(6,3))
print("string is:",string)
