import calculator
a=int(input("Enter a value:"))
b=int(input("Enter b value:"))
print ("addition is:",calculator.sume(a,b))
print ("substraction is:",calculator.subs(a,b))
print ("multiplication is:",calculator.mult(a,b))
print ("division is:",calculator.divi(a,b))
print ("string is:",calculator.string)

