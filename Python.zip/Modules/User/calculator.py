def sume(a,b):
	return a+b
def subs(a,b):
	return a-b
def mult(a,b):
	return a*b
def divi(a,b):
	return a/b
string="Hello I am a module"
