u_list=[10,"Hi",3.14,"Hello"]
u_list[0]=100
print("Forward Index")
print("u_list[0]:",u_list[0])
print("u_list[1]:",u_list[1])
print("u_list[2]:",u_list[2])
print("u_list[3]:",u_list[3])
print("Backward Index")
print("u_list[-1]:",u_list[-1])
print("u_list[-2]:",u_list[-2])
print("u_list[-3]:",u_list[-3])
print("u_list[-4]:",u_list[-4])
