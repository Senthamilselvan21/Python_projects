list1=[100,269,32,269,1000,269,21]
 
print ("Biggest element in list1:",max(list1))
 
print ("Smallest element in list1:",min(list1))
 
print ("sum of elements in list1:",sum(list1))
 
print ("count the number of elements in list1:",len(list1))
 
print ("count the element occurrence no.of times:",list1.count(269))
