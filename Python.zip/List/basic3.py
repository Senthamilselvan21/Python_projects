u_list=[1,2,3]
print(u_list*1)
print(u_list*2)
print(u_list*3)
print(u_list*4)
