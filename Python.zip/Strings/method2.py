string="i am leArNing pyThON"
str3="This is worst world baby" 
 
print ("String in lower cases:",string.lower())
 
print ("String in upper cases:",string.upper())
 
print ("String in first char upper case:",string.capitalize())
 
print ("String in title:",string.title())
 
print ("String in swapcase:",string.swapcase())
print ("split is:",str3.split())
