string="i hi hello hai how hai are hai you?"
string1="hello"
print ("The string is find at:",string.find("hai"))
print ("The string is rfind at:",string.rfind("hai"))
print ("The string is find at:",string.find("hey"))
print ("The string is startwith:",string1.startswith("he"))
print ("The string is endswith:",string1.endswith("la"))


