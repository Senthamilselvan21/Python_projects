str1="123"
str2="hai"
str3="hai123"
str4="ABD"
str5="abcd "
str6="    "
print ("isalnum is:",str1.isalnum())
print ("isalnum is:",str2.isalnum())
print ("isalpha is:",str2.isalpha())
print ("isalpha is:",str1.isalpha())
print ("isdigit is:",str1.isdigit())
print ("isdigit is:",str3.isdigit())
print ("islower is:",str2.islower())
print ("isupper is:",str4.isupper())
print ("isspace is:",str6.isspace())

