str1='I am single quote string'
str2="I am double quote string"
str3='''I am triple quote string'''
print ("string1 is:",str1)
print ("string2 is:",str2)
print ("string3 is:",str3)
print("*********************")
name="Besant"
#name[0]='k'
print("Forward")
print(name[0])
print(name[1])
print(name[2])
print(name[3])
print(name[4])
print(name[5])
print("backward")
print(name[-1])
print(name[-2])
print(name[-3])
print(name[-4])
print(name[-5])
print(name[-6])
