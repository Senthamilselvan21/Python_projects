name="Besant"
length=len(name)
i=0
for j in range(1,length+1):
	print ("Forward is:",name[i])
	print ("Backward is:",name[-j])
	i=i+1
